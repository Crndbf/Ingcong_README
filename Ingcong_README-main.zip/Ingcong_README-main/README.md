# Ingcong_README
"New to coding, exploring. Sharing my learning journey. Let's connect &amp; learn together! 🖥️💻🌟 |"
